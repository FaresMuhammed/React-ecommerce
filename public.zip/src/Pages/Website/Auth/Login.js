// npm i cookie-universal

import axios from "axios";
import { useState } from "react"
import { LOGIN, URL } from "../../../API/Api";
import Loading from "../../../Componants/Loading/Loading";
import Cookie from  'cookie-universal'
import ph from './OIP.jpeg'

import Form from 'react-bootstrap/Form';
import { useNavigate } from "react-router-dom";


export default function Login() {

  const navigate = useNavigate()
  
  // States
  const [Formm , setFormm ]= useState({
    email: '',
    password: ''
  })
  const [Error , setError] = useState('')
  const [loading , setloading] = useState(false)

  // form change
  function Handlechange(e) {
    setFormm({ ...Formm , [e.target.name]: e.target.value })
  }

  // cookie
  const cookie = Cookie()

  async function Handlesubmit(e) {
    e.preventDefault();
    setloading(true)
    try{
      const res = await axios.post(` ${URL}/${LOGIN}` , {
        email: Formm.email , 
        password: Formm.password
      })
      setloading(false)
      console.log(res)
      const token = res.data.token
      cookie.set('ecommerce' , token)
      window.location.pathname = '/dashboard/users'
    }
    catch (err) {
      setloading(false)
      if (err.response.status === 401) {  // 401(unauthorized) email or password is wrong  ,, 401(unauthanticated) if you do anything without send token
        setError( <div className="center"> Wrong Email Or Password </div>)
      }else{
        setError('Internal Server Error')
      }
    }
  }

  return (
    <>
    
    {loading && <Loading/>}
    <div className='container'>
      <div className="row" style={{height: '100vh'}}>
        <Form className="form " onSubmit={Handlesubmit}>
          <div className="center">

            <div className="custom-form">

              <h1 className="h1"> Login </h1>
              
              <Form.Group className="form-custom mb-3">
                <Form.Control id='email' type='email' placeholder='Enter Your Email...'
                name="email"
                value={Formm.email}
                onChange={Handlechange}
                required
                />
                <Form.Label htmlFor='email'>Email</Form.Label>

              </Form.Group>            
              
              <Form.Group className="form-custom mb-3">
                <Form.Control id='password' type='password' placeholder='Enter Your Password'
                name="password"
                value={Formm.password}
                onChange={Handlechange}
                // valid conditions
                required
                minLength='6'
                />
                <Form.Label htmlFor='password'>Password</Form.Label>
              </Form.Group>
              
              <button className="btn btn-primary center" type='submit'>Login</button>
              
              <div className="or center">OR</div>
              
              <div className="center">
                <div className="google-btn ">
                  <a  href="http://127.0.0.1:8000/login-google">
                    <div className="google-icon-wrapper">
                      <img
                      className="google-icon"
                      src={ph}
                      alt="Sign in wiwth google"
                      />
                    </div>
                    <p className="btn-text">
                      <b>Login with google</b>
                    </p>
                  </a>
                </div>
              </div>
              {Error !== '' && <span className="error ">{Error}</span>}

            </div>
          </div>
        </Form>
      </div>
    </div>
  </>
  )
}
