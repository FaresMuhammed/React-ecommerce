import { Navigate, Outlet, useNavigate } from "react-router-dom";
import Cookie from  'cookie-universal'
import { useEffect, useState } from "react";
import { USER } from "../../../API/Api";
import Loading from "../../../Componants/Loading/Loading";
import { Axios } from "../../../API/Axios";
import Error403 from "./Error403";


export default function Requireauth(Allowedrole) {

    const navigate = useNavigate()

    // to get token
    const cookie = Cookie()
    const token = cookie.get('ecommerce')

    // to get user
    const [ User , setUser ] = useState('')   // the signed user

    // to store user's data in user
    useEffect ( () => {
        Axios
        .get(`/${USER}` )
        .then( data => setUser(data.data))  // now when login the data will be in user
        .catch( () => navigate( '/login' , {replace: true}))  // if there is error , just return to login page directly
    } , [] )
    console.log(User);

    // to potect routes from access without login & any cookie edit from user
    return token ? (         // to wont access without token
            User === '' ?    // data still haven't come 
            (<Loading/>)
            : Allowedrole.includes(User.role) ?  // if allowed role includes current user
            (<Outlet/>) : (<Error403/>)
        ) : 
        (<Navigate to={'/login'} replace={true}/> ) // replace (true) delete the last page and return to the last last
}