import { useEffect, useState } from "react"
import { USER, USERS } from "../../API/Api"
import { Table } from "react-bootstrap"
import { Axios } from "../../API/Axios"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faPenToSquare } from "@fortawesome/free-regular-svg-icons"
import { faTrash } from "@fortawesome/free-solid-svg-icons"
import { Link } from "react-router-dom"

export default function Users() {

    const [refresh , setRefresh] = useState(0)             // to sovlve the refresh problem
    const [users , setusers] = useState([])                // to get all users
    const [currentUser , setcurrentUser] = useState('')    // to get current user
    const [noUsers , setnoUsers] = useState(false) 


    // useeffect to get current user
    useEffect(() => {
        Axios
        .get(`${USER}`)
        .then( res => setcurrentUser(res.data))   // now current user is in currentuser
    } , [] )

    // useeffect to set all users in state users
    useEffect ( () => {
        Axios.
        get(`/${USERS}`)
        .then( data => setusers(data.data))   // you can set mare than usestate in one useeffect
        .then( () => setnoUsers(true))        // to make condition after the useeffect runs
        .catch(err => (err) )
    } , [refresh] )    // will reun directly after delete(refresh users every delete)


    const ID = Number(window.location.pathname.replace('/dashboard/users/' , '')) 

    async function handleDelete(ID) {
        if (currentUser.id !== ID) {       // to disable delete currentuser
            await Axios.delete(`${USER}/${ID}`)
            setRefresh( (refresh) => refresh + 1)
        }
    }  
    const showusers = users.map ((user , key) =>

    <tr key={key}>
        <td>{key + 1}</td>
        <td>{user.name === currentUser.name ? user.name + ' (You)' : user.name }</td>
        <td>{user.email}</td> 
        <td>{user.role === '1995' ? 'Admin' : user.role === '2001' ? 'User' : 'Writter'}</td> {/* 1995 admin , 2001 user , from backend  */}
        <td>
            <Link to={`${user.id}`}>
                <FontAwesomeIcon fontSize={'19px'} color="blue"  icon={faPenToSquare}/>
            </Link>
        </td>
        
        <td onClick={ () =>  handleDelete(user.id)}>
            {user.name !== currentUser.name ?
                <FontAwesomeIcon fontSize={'19px'} color="red" cursor={'pointer'} icon={faTrash}/>
                : <FontAwesomeIcon fontSize={'19px'} color="grey" icon={faTrash} />
            }
        </td>
    </tr> )

    return (
    <div className=" w-100 p-2">
        <h1>Users Page</h1>
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                {users.length === 0 ? (  // it happend when loading users 
                    <tr>
                        <td colSpan={12} className="text-center">Loading...</td>
                    </tr>) : 
                        users.length === 0 && noUsers  ?  // nousers runs with the useeffect who gets users, it means if the users lengh equals 0 after the use effect runs(no users already)   ( if it equals 1 it means the currentuser only)
                        <td colSpan={12} className="text-center">No Users Found</td>
                    : (showusers) }
            </tbody>
        </Table>
    </div>
    )
}