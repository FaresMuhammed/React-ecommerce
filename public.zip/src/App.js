import { Route, Routes } from 'react-router-dom';

// import Homepage from './Pages/Website/Homepage';
import Login from './Pages/Website/Auth/Login';
import Register from './Pages/Website/Auth/Register';
import Users from './Pages/Dashboard/Users';
import GoogleCallBack from './Pages/Website/Auth/GoogleCallBack';
import Dashboard from './Pages/Dashboard/Dashboard';
import Requireauth from './Pages/Website/Auth/Requireauth';
import UpdateUser from './Pages/Dashboard/Upadateuser';
import Adduser from './Pages/Dashboard/Adduser';
// import Error403 from './Pages/Website/Auth/Error403';/
import Writer from './Pages/Dashboard/Writer';


export default function App() {
  return (
    <div>

      <Routes>
        
        {/* puplic routes */}
        <Route path="/" element={<Dashboard/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path='/auth/google/callback' element={<GoogleCallBack/>}/>

        {/* protected routes */}
        {/* <Route element={<Requireauth/>}>  */}

          <Route path='/dashboard' element={<Dashboard/>}>
            <Route element={<Requireauth Allowedrole = {['1995']}/>} >  {/* won't access if your role isnt admin */}
              <Route path='users' element={<Users/>}/>
              <Route path='users/:id' element={<UpdateUser/>}/>
              <Route path='user/add' element={<Adduser/>}/>
            </Route>
            <Route element={<Requireauth Allowedrole = {['1996' , '1995']}/>}>
              <Route path='writer' element={<Writer/>}/>
            </Route>
          </Route>
        {/* </Route> */}
      </Routes>
    </div>
  )
}