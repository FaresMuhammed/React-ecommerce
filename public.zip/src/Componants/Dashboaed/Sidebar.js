import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import './bars.css'
import { faPlus, faUsers } from '@fortawesome/free-solid-svg-icons'
import { NavLink } from 'react-router-dom'
import { useContext } from "react";
import { Menu } from "../../Context/Menucontext";
import { WindowSize } from '../../Context/Windowcontext';

export default function Sidebar() {

    const menu = useContext(Menu)
    const Isopen = menu.Open

    const WindowContext = useContext(WindowSize)
    const windowSize = WindowContext.windowSize

    return (
        <>
            <div style={{
                position: 'fixed',
                top: '70px',
                left: '0',
                width: '100%',
                height: '100vh',
                backgroundColor: 'rgba(0, 0, 0, 0.2)',
                display: windowSize < '768' && Isopen ? 'block' : 'none'
            }}>
            </div>

            <div className='side-bar pt-3'
                style={{
                    left: windowSize < '768' ? (Isopen ? 0 : '-100%' ) : 0 ,  // CONDITION IN CONDITION
                    width: Isopen ? '240px' : 'fit-content',
                    position: windowSize < '768'? 'fixed' : 'sticky'
                }}>
                {/* navlink have class (active) */}
                <NavLink 
                    to='users' 
                    className='d-flex align-items-center gap-2 side-bar-link'
                    >
                    <FontAwesomeIcon 
                        icon={faUsers}
                        style={{padding: Isopen ? '15px 8px 15px 15px' :'15px'}}
                    />
                    <p className='m-0' style={{
                        display: Isopen ? 'block' : 'none'}}>
                            Users
                    </p>
                </NavLink>

                <NavLink 
                    to={'/dashboard/user/add'}
                    className='d-flex align-items-center gap-2 side-bar-link'
                >
                    <FontAwesomeIcon 
                        icon={faPlus}
                        style={{padding: Isopen ? '15px 8px 15px 15px' :'15px'}}
                    />
                    <p className='m-0' style={{
                        display: Isopen ? 'block' : 'none'}}>
                        Add User
                    </p>
                </NavLink>

                <NavLink 
                    to={'/dashboard/writer'}
                    className='d-flex align-items-center gap-2 side-bar-link'
                >
                    <FontAwesomeIcon 
                        icon={faPlus}
                        style={{padding: Isopen ? '15px 8px 15px 15px' :'15px'}}
                    />
                    <p className='m-0' style={{
                        display: Isopen ? 'block' : 'none'}}>
                        Writer
                    </p>
                </NavLink>

            </div>
        </>
    )
}