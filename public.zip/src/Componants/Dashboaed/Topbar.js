import { faBars } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useContext, useEffect, useState } from "react";
import { Menu } from "../../Context/Menucontext";
import { LOGOUT, USER } from "../../API/Api";
import { Axios } from "../../API/Axios";
import { DropdownButton } from "react-bootstrap";
import DropdownItem from "react-bootstrap/esm/DropdownItem";
import Cookie from "cookie-universal"


export default function Topbar() {

    const cookie = Cookie()

    const menu = useContext(Menu)
    const toopen = menu.setOpen

    const [Username , setUsername] = useState('')
    // to get the signed user now (to get his name and show him above the page)
    useEffect ( () => {
        Axios
        .get(`/${USER}`)
        .then( data => setUsername(data.data.name))
        // .catch( () => navigate( '/login' , {replace: true}))  // if there is error , just return to login page directly
    } , [] )

    // to make logout as a choose for the button
    function Handlelogout() {
        Axios.get( `/${LOGOUT}`)
        window.location.pathname = '/login'
        cookie.remove('ecommerce')   // u must delete token with log out (it won't delete user)
    }

    return (
    <div className="top-bar ">
        <div className="d-flex align-items-center justify-content-between h-100">
            <div className="d-flex align-items-center gap-5">
                <h3>E-Commerce</h3>
                <FontAwesomeIcon onClick={ () => toopen( prev => !prev )} cursor= {'pointer'} icon={faBars}  />
            </div>
            <div >
                <DropdownButton id="dropdown-basic-button" title={Username}>
                    <DropdownItem onClick={Handlelogout} >Logout</DropdownItem>
                </DropdownButton>
            </div>
            
        </div>
    </div>
    )
}