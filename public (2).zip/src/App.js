import { Route, Routes } from 'react-router-dom';

import Homepage from './Pages/Website/Homepage';
import Login from './Pages/Auth/Login';
import Register from './Pages/Auth/Register';
import Users from './Pages/Dashboard/Users';
import GoogleCallBack from './Pages/Auth/GoogleCallBack';
import Dashboard from './Pages/Dashboard/Dashboard';
import Requireauth from './Pages/Auth/Requireauth';
import UpdateUser from './Pages/Dashboard/Upadateuser';
import Adduser from './Pages/Dashboard/Adduser';
import Writer from './Pages/Dashboard/Writer';
import Error404 from './Pages/Auth/Error404';
import RequireLogin from './Pages/Auth/RequireLogin';
import Categories from './Pages/Dashboard/Categories';
import AddCategoery from './Pages/Dashboard/AddCategoery';
import UpdateCategory from './Pages/Dashboard/UpdateCategory';
import Products from './Pages/Dashboard/Products';
import AddProduct from './Pages/Dashboard/AddProduct';


export default function App() {
  return (
    <div>

      <Routes>
        
        {/* puplic routes */}
        <Route path="/" element={<Homepage/>}/>
        <Route element={<RequireLogin/>}>
          <Route path="/register" element={<Register/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path='/auth/google/callback' element={<GoogleCallBack/>}/>
        </Route>


        <Route element={<Error404/>} path='/*'/>    {/*it means any path isnt here */}

        {/* protected routes */}
        <Route element={<Requireauth Allowedrole={['1996' , '1995' , '1999']}/>}>   {/* 2001 normal user won't access the dashboard */}
          <Route path='/dashboard' element={<Dashboard/>}>

            <Route element={<Requireauth Allowedrole = {['1995']}/>} >  {/* won't access if your role isnt admin */}
              <Route path='users' element={<Users/>}/>
              <Route path='users/:id' element={<UpdateUser/>}/>
              <Route path='user/add' element={<Adduser/>}/>
            </Route>

            <Route element={<Requireauth Allowedrole = {['1999' , '1995']}/>}>
              
              {/* Categories */}
              <Route path='categories' element={<Categories/>}/>
              <Route path='category/add' element={<AddCategoery/>}/>
              <Route path='categories/:id' element={<UpdateCategory/>}/>

              {/* Products */}
              <Route path='products' element={<Products/>}/>
              <Route path='product/add' element={<AddProduct/>}/>

            </Route>

            <Route element={<Requireauth Allowedrole = {['1996' , '1995']}/>}>
              <Route path='writer' element={<Writer/>}/>
            </Route>

          </Route>

        </Route>
      </Routes>
    </div>
  )
}