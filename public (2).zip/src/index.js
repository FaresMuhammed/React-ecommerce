import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { BrowserRouter as Router } from 'react-router-dom';

import './index.css';
import './CssComponants/button.css';
import './CssComponants/alerts.css';
import './CssComponants/Loading.css';
import './CssComponants/google.css';
import './Pages/Auth/Auth.css'

// reactstrap
import 'bootstrap/dist/css/bootstrap.min.css';
import Menucontext from './Context/Menucontext';
import Windowcontext from './Context/Windowcontext';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Windowcontext>
    <Menucontext>
      <Router>
        <App />
      </Router>
    </Menucontext>
    </Windowcontext>
  </React.StrictMode>
)