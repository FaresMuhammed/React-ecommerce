export const URL = `http://127.0.0.1:8000/api`
// AUTH
export const REGISTER = 'register'
export const LOGIN = 'login'
export const LOGOUT = 'logout'
// USERS
export const USERS = 'users' // to show in dashboard
// USER
export const USER = 'user' // to protect the website
// callback
export const GOOGLE = 'auth/google/callback'
// categories
export const CATEGORIES = 'categories'
export const CATEGORY = 'category'
// products
export const PRODUCTS = 'products'
export const PRODUCT = 'product'