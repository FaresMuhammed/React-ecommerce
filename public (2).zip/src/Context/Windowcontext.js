// a context to get the width by secend
import { createContext, useEffect, useState } from "react";


export const WindowSize = createContext(null)

export default function WindowContext({children}) {

    const [windowSize , setWindowSize] = useState(window.innerWidth)  // state have the screen width

    useEffect(()=> {           // we use useeffect to use addeventlistener
        function setWindowWidth() {
            setWindowSize(window.innerWidth)   // a fun make the new size equals the last
        }
        window.addEventListener("resize", setWindowWidth)  // it means when resize run the fun Widthwindow , addEventListener listenes to the resize

        return () => {
            window.removeEventListener("resize", setWindowWidth)
        }
    } , [])

    return (
    <WindowSize.Provider value={{windowSize}}>   {/* all the above(screen size) is in the context */}
        {children}
    </WindowSize.Provider>
    )
}