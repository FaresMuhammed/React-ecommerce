import { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import Loading from '../../Componants/Loading/Loading'
import { Axios } from '../../API/Axios'
import { CATEGORIES } from '../../API/Api'
import Categories from './Categories'

// import Loading from '../../Componants/Loading/Loading'

export default function AddProduct() {

    const [Load , setLoad]= useState(false)


    const [Form , setForm ]= useState({
        category: '',
        title: '',
        description: '',
        price: '',
        discount: '',
        About: '',
    })

    function Handlechange(e) {      // e is the action (writing in input) , target is the goal(input)
        setForm({ ...Form , [e.target.name]: e.target.value })
    }

    const [Images , setImages ]= useState([            // array cuz of photos

    ])


    // useeffect to get categories 
    const [Categoriess , setCategoriess] = useState([])

    useEffect ( () => {
        Axios.
        get(`/${CATEGORIES}`)
        .then( data => setCategoriess(data.data))
        .catch(err => (err) )
    } , [] )

    // const to show categories
    const ShowCategories = Categoriess.map ( (category , key) => <option key={key} value={category.id}>{category.title}</option>)

    // async function Handlesubmit(e) {
    //     setLoad(true)
    //     e.preventDefault()
    //     // how to send image
    //     const Form = new FormData()
    //     Form.append('title', Form.title)

    //     await Axios
    //     .post(`${PRODUCT}/add` , Form)
    //     window.location.pathname = '/dashboard/products'

    // }

    return (
            <>
                {Load && <Loading/>}

                <Form  className='bg-white w-100 mx-2 p-3'>

                    <Form.Group className="mb-3" controlId="category">
                        <Form.Label>Category</Form.Label>
                        <Form.Select 
                            placeholder="Enter Title" 
                            value={Form.category}
                            onChange={Handlechange}
                            name='category'
                        >
                            {ShowCategories}
                        </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="title">
                        <Form.Label>Title</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" 
                        value={Form.title}
                        onChange={Handlechange}
                        name='title'

                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="description">
                        <Form.Label>Description</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" 
                        value={Form.description}
                        onChange={Handlechange}
                        name='description'
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="price">
                        <Form.Label>Price</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" 
                        value={Form.price}
                        onChange={Handlechange}
                        name='price'
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="discont">
                        <Form.Label>Discont</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" 
                        value={Form.discount}
                        onChange={Handlechange}
                        name='discont'
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="about">
                        <Form.Label>About</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" 
                        value={Form.About}
                        onChange={Handlechange}
                        name='about'
                        />
                    </Form.Group>


                    <Button disabled={Form.title.length > 1 ? false : true } className='d-flex ' variant="primary" type="submit">
                        Add
                    </Button>

                </Form>
            </>
    )
}