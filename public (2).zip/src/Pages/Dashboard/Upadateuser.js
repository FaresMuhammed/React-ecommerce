import React, { useEffect, useState } from 'react'
import { Button, Form } from 'react-bootstrap'
import { Axios } from '../../API/Axios'
import { USER } from '../../API/Api'
import Loading from '../../Componants/Loading/Loading'
import { useNavigate } from 'react-router-dom'

export default function Updateuser() {

    const Nav = useNavigate()  // navigate doesnt make reload

    const ID = Number(window.location.pathname.replace('/dashboard/users/' , ''))  // new way to get id

    const [Name , setName] = useState('')
    const [Email , setEmail] = useState('')
    const [Load , setLoad] = useState(false)
    const [Role , setRole] = useState('')

    async function Handlesubmit(e) {
        setLoad(true)
        e.preventDefault()
        await Axios
        .post(`${USER}/edit/${ID}`  , {name: Name , email: Email , role: Role } )
        window.location.pathname = '/dashboard/users'
    }


    useEffect (() => {
        setLoad(true)
        Axios
        .get(`${USER}/${ID}`)
        .then ( (data) => {            // now you got user data by id
        setName(data.data.name)        // the name is the user's name
        setEmail(data.data.email)
        setRole(data.data.role)
        setLoad(false)
    }).catch(() => Nav('/dashboard/users/page/404' , {replace: true}))       // if there is error(it will be error if id not found) go to unkown page(to show error404)
    } , [] )

    return (
            <>
                {Load && <Loading/> }

                <Form onSubmit={Handlesubmit} className='bg-white w-100 mx-2 p-3'>

                    <Form.Group className="mb-3" controlId="formBasicNameee">
                        <Form.Label>User Name</Form.Label>
                        <Form.Control type="text" placeholder="Enter Name" 
                        value={Name}
                        onChange={ (e) => setName(e.target.value) } // to change the value the value 
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicEmailll">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter Email"
                        value={Email}
                        onChange={ (e) => setEmail(e.target.value) }
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicRole">
                        <Form.Label>Role</Form.Label>
                        <Form.Select
                            value={Role}
                            onChange={(e) => setRole(e.target.value)}
                            >
                            <option disabled value=''>Select Role</option>
                            <option value='1995'>Admin</option>
                            <option value='2001'>User</option>
                            <option value='1996'>Writer</option>
                        </Form.Select>
                    </Form.Group>

                    <Button disabled={Name.length > 1 && Email.length > 1 && Role !== '' ? false : true } className='d-flex ' variant="primary" type="submit">
                        Update
                    </Button>

                </Form>
            </>
    )
}