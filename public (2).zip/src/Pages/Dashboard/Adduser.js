import { useState } from 'react'
import { Button, Form } from 'react-bootstrap'
import { Axios } from '../../API/Axios'
import { USER } from '../../API/Api'
import Loading from '../../Componants/Loading/Loading'

export default function Adduser() {

    const [Name , setName] = useState('')
    const [Email , setEmail] = useState('')
    const [Password , setPassword] = useState('')
    const [Role , setRole] = useState('')
    const [Load , setLoad] = useState(false)

    async function Handlesubmit(e) {
        setLoad(true)
        e.preventDefault()
        await Axios
        .post(`${USER}/add` , {name: Name , email: Email , password: Password , role: Role } )
        window.location.pathname = '/dashboard/users'
    }
    

    return (
            <>
                {Load && <Loading/> }

                <Form onSubmit={Handlesubmit} className='bg-white w-100 mx-2 p-3'>

                    <Form.Group className="mb-3" controlId="formBasicNameee">
                        <Form.Label>User Name</Form.Label>
                        <Form.Control type="text" placeholder="Enter Name" 
                        value={Name}
                        onChange={ (e) => setName(e.target.value) } // to change the value the value 
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicEmailll">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter email"
                        value={Email}
                        onChange={ (e) => setEmail(e.target.value) }
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicPass">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" placeholder="Enter Password"
                        value={Password}
                        onChange={ (e) => setPassword(e.target.value) }
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicRole">
                        <Form.Label>Role</Form.Label>
                        <Form.Select
                            value={Role}
                            onChange={(e) => setRole(e.target.value)}
                            >
                            <option disabled value=''>Select Role</option>
                            <option value='1995'>Admin</option>
                            <option value='2001'>User</option>
                            <option value='1996'>Writer</option>
                            <option value='1999'>Product Maneger</option>
                        </Form.Select>
                    </Form.Group>
                                                                                                               {/* if all of this achieved make the disabled false(enabled) */}
                    <Button disabled={Name.length > 1 && Email.length > 1 && Password.length > 6 && Role !== '' ? false : true } className='d-flex ' variant="primary" type="submit">
                        Add
                    </Button>

                </Form>
            </>
    )
}