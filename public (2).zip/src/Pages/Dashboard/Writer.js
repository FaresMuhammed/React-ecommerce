
export default function Writer() {
    return (
    <div>
        fffkkk
    </div>
    )
}