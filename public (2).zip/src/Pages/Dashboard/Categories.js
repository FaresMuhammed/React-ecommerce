import { useEffect, useState } from "react"
import { CATEGORIES, CATEGORY } from "../../API/Api"
import { Axios } from "../../API/Axios"
import Tables from "../../Componants/Dashboaed/Table"

export default function Categories() {

    // Categories header
    const CategoriesHeader = [
        {name: 'Title' ,keyy: 'title'} ,
        {name: 'Image' ,keyy: 'image'} 
    ]

    // to get categories
    const [Categoriesrss , setCategoriess] = useState([])

    useEffect ( () => {
        Axios.
        get(`/${CATEGORIES}`)
        .then( data => setCategoriess(data.data))
        .catch(err => (err) )
    } , [] )

    async function handleDelete(id) {
        await Axios.delete(`${CATEGORY}/${id}`)
            setCategoriess((previous) => previous.filter((item) => item.id !== id ) )
        }    

    return (
    <div className=" w-100 p-2">
        <h1>Categories Page</h1>
        <Tables 
            Header={CategoriesHeader} 
            Data={Categoriesrss}
            Delete={handleDelete}
        />
    </div>
    )
}