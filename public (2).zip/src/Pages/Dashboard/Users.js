import { useEffect, useState } from "react"
import { USER, USERS } from "../../API/Api"
import { Axios } from "../../API/Axios"
import Tables from "../../Componants/Dashboaed/Table"

export default function Users() {

    // table's Header in Users
    const UsersHeader = [
                   // keyy's value from backend(it have the value)
        {name: 'User Name' , keyy: 'name'} ,    // it have name's value
        {name: 'Email' , keyy: 'email'} ,
        {name: 'Role'  , keyy: 'role'}
    ]
    // table's Data in Users is Users

    const [users , setusers] = useState([])                // to get all users
    const [currentUser , setcurrentUser] = useState('')    // to get current user


    // useeffect to get current user
    useEffect(() => {
        Axios
        .get(`${USER}`)
        .then( res => setcurrentUser(res.data))   // now current user is in currentuser
    } , [] )

    // useeffect to set all users in state users
    useEffect ( () => {
        Axios.
        get(`/${USERS}`)
        .then( data => setusers(data.data))   // you can set mare than usestate in one useeffect
        .catch(err => (err) )
    } , [] )    // will reun directly after delete(refresh users every delete)



    async function handleDelete(id) {
        await Axios.delete(`${USER}/${id}`)
            setusers((previous) => previous.filter((item) => item.id !== id ) )
        }    
    
    return (
    <div className=" w-100 p-2">
        <h1>Users Page</h1>
        <Tables 
            Header={UsersHeader} 
            Data={users} 
            currentUser={currentUser}
            Delete= {handleDelete}
        />
    </div>
    )
}