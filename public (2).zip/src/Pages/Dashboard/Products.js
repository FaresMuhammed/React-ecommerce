import { useEffect, useState } from "react"
import {  PRODUCT, PRODUCTS } from "../../API/Api"
import { Axios } from "../../API/Axios"
import Tables from "../../Componants/Dashboaed/Table"

export default function Products() {

    // Categories header
    const ProductsHeader = [
        {name: 'Title' ,keyy: 'title'} ,
        {name: 'Description' ,keyy: 'description'} ,
        {name: 'Price' ,keyy: 'price'} ,
        {name: 'Rate' ,keyy: 'rating'} ,
    ]

    const [Products , setProducts] = useState([])

        useEffect ( () => {
        Axios.
        get(`/${PRODUCTS}`)
        .then( data => setProducts(data.data))
        .catch(err => (err) )
    } , [] )

    async function handleDelete(id) {
        await Axios.delete(`${PRODUCT}/${id}`)
            setProducts((previous) => previous.filter((item) => item.id !== id ) )
        }    

    return (
    <div className=" w-100 p-2">
        <h1>Products Page</h1>
        <Tables 
            Header={ProductsHeader} 
            Data={Products}
            Delete={handleDelete}
        />
    </div>
    )
}