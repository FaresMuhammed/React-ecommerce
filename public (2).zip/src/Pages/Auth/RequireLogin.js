import Cookie from  'cookie-universal'
import {  Outlet } from 'react-router-dom'

export default function RequireLogin() {

    // to get last path use javascript cuz of reload(usenavigate doesnt work with reload) )

    const cookie = Cookie()
    const token = cookie.get('ecommerce')

    return (
    <div>
        {token ? window.history.back() : <Outlet/>}  {/* if he already signed and go to signin or register , return to last page */}
    </div>
    )
}