import { faPenToSquare } from '@fortawesome/free-regular-svg-icons'
import { faTrash } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Table } from 'react-bootstrap'
import { Link } from 'react-router-dom'

export default function Tables(props) {   // table's header&data will change in every page

    // DEFAULT VALUE  to make a condition on one page or more ()
    const Currentuser = props.currentUser  || {name: ''}   // if there is currentuser show it , if it isn't show false only (won't make error)

    // Show Table
    const ShowHeader = props.Header.map((item) => <th>{item.name}</th>)
    const ShowData = props.Data.map((item , key) =>(          // item is $users's object
        <tr key={key}>
            
            <td>{key + 1}</td>
            
            {props.Header.map((item2 , key2) =>(               // map in map(map on header to get $users's object value from $UsersHeader)  ,,  // item2.keyy have the value
            <td key={key2}>
                {
                    item2.keyy === 'image' ? <img width='80px' src={item[item2.keyy]} />         // a condition if the value is image , show in as image

                    : item[item2.keyy] === '1995' ? 'Admin'     // a condition on role 
                    : item[item2.keyy]  === '1996' ? 'Writer'  // 1995 admin , 2001 user , from backend
                    : item[item2.keyy]  === '2001' ? 'User'
                    : item[item2.keyy] === '1999' ? 'Product Maneger'
                    : item[item2.keyy]                                  // it item's value isn't role show it as it is
                }
                {
                    Currentuser && item[item2.keyy] === Currentuser.name && ' (You)'  // if the page have current user and his name equals item name add 'You' 
                }
            </td>
            ))}
            
            <td>
                <Link to={`${item.id}`}>
                    <FontAwesomeIcon fontSize={'19px'} color="blue"  icon={faPenToSquare}/>
                </Link>
            </td>
            
            <td onClick={ () =>props.Delete(item.id)}>
                {Currentuser.name !== item.name ?
                <FontAwesomeIcon fontSize={'19px'} color="red" cursor={'pointer'} icon={faTrash}/>
                : <FontAwesomeIcon fontSize={'19px'} color="grey" icon={faTrash} />}
            </td>

        </tr>
        ))

    return (
    <div>
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>ID</th>
                    {ShowHeader}
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                {props.Data.length === 0 &&   //while loading
                    <tr>
                        <td colSpan={12} className='text-center'>Loading...</td>
                    </tr>
                }
                {ShowData}
            </tbody>
        </Table>
    </div>
    )
}